document.addEventListener('DOMContentLoaded', () => {
    const numberDisplay = document.querySelector('.generated-number');
    const generateBtn = document.getElementById('generate');
    const minInput = document.getElementById('min');
    const maxInput = document.getElementById('max');
    const animationSelect = document.getElementById('animation-style');
    const themeButtons = document.querySelectorAll('.theme-btn');
    const soundToggle = document.getElementById('sound-toggle');
    const soundEffect = document.getElementById('sound-effect');
    const container = document.querySelector('.container');

    // Add tilt effect to all buttons
    const buttons = [...themeButtons, generateBtn];
    buttons.forEach(btn => addTiltEffect(btn));

    function addTiltEffect(element) {
        let rect = element.getBoundingClientRect();
        let mouseX = 0;
        let mouseY = 0;

        element.addEventListener('mousemove', (e) => {
            mouseX = e.clientX - rect.left;
            mouseY = e.clientY - rect.top;
            
            const xRotation = 20 * ((mouseY - rect.height / 2) / rect.height);
            const yRotation = -20 * ((mouseX - rect.width / 2) / rect.width);
            
            element.style.transform = `perspective(500px) scale(1.05) rotateX(${xRotation}deg) rotateY(${yRotation}deg)`;
        });

        element.addEventListener('mouseleave', () => {
            element.style.transform = 'perspective(500px) scale(1) rotateX(0) rotateY(0)';
        });
    }

    function adjustFontSize() {
        const numberLength = numberDisplay.textContent.length;
        const baseSize = 10; // rem
        const newSize = baseSize - (numberLength * 0.5);
        numberDisplay.style.fontSize = `${Math.max(4, newSize)}rem`;
    }

    const animations = {
        bounce: () => {
            numberDisplay.animate([
                { transform: 'translateY(0) scale(1) rotate(0deg)', offset: 0 },
                { transform: 'translateY(-70px) scale(1.4) rotate(-5deg)', offset: 0.3 },
                { transform: 'translateY(30px) scale(0.8) rotate(5deg)', offset: 0.6 },
                { transform: 'translateY(-15px) scale(1.1) rotate(-2deg)', offset: 0.8 },
                { transform: 'translateY(0) scale(1) rotate(0deg)', offset: 1 }
            ], {
                duration: 1200,
                easing: 'cubic-bezier(0.36, 0, 0.66, 1)'
            });
        },
        spin: () => {
            numberDisplay.animate([
                { transform: 'perspective(1000px) rotateY(0deg) translateZ(0px) scale(1)', opacity: 1 },
                { transform: 'perspective(1000px) rotateY(180deg) translateZ(200px) scale(1.5)', opacity: 0.8, offset: 0.5 },
                { transform: 'perspective(1000px) rotateY(360deg) translateZ(0px) scale(1)', opacity: 1 }
            ], {
                duration: 1500,
                easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
            });
        },
        glitch: () => {
            const colors = ['#ff0000', '#00ff00', '#0000ff'];
            const keyframes = [];
            for(let i = 0; i < 10; i++) {
                keyframes.push({
                    transform: `translate(${Math.random()*20-10}px, ${Math.random()*20-10}px) scale(${0.95 + Math.random()*0.2})`,
                    textShadow: `${Math.random()*10-5}px ${Math.random()*10-5}px 5px ${colors[i % 3]}`,
                    filter: `hue-rotate(${Math.random()*360}deg) brightness(${1 + Math.random()})`,
                    offset: i/10
                });
            }
            numberDisplay.animate(keyframes, {
                duration: 500,
                iterations: 4
            });
        },
        portal: () => {
            numberDisplay.animate([
                { transform: 'scale(1) rotate(0deg)', filter: 'blur(0px) brightness(1)', opacity: 1 },
                { transform: 'scale(0.1) rotate(360deg)', filter: 'blur(20px) brightness(2)', opacity: 0, offset: 0.5 },
                { transform: 'scale(2) rotate(720deg)', filter: 'blur(20px) brightness(2)', opacity: 0, offset: 0.7 },
                { transform: 'scale(1) rotate(1080deg)', filter: 'blur(0px) brightness(1)', opacity: 1 }
            ], {
                duration: 1800,
                easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
            });
        },
        explosion: () => {
            const particles = Array.from({ length: 60 }, () => {
                const particle = document.createElement('div');
                particle.className = 'explosion-particle';
                const angle = Math.random() * 360;
                const distance = 100 + Math.random() * 350;
                const width = 2 + Math.random() * 4;
                const height = 10 + Math.random() * 30;
                const duration = 800 + Math.random() * 800;
                
                particle.style.cssText = `
                    --angle: ${angle}deg;
                    --distance: ${distance}px;
                    width: ${width}px;
                    height: ${height}px;
                    animation-duration: ${duration}ms;
                    transform: rotate(${angle}deg);
                    opacity: ${0.5 + Math.random() * 0.5};
                `;
                return particle;
            });
        
            particles.forEach(p => numberDisplay.appendChild(p));
        
            numberDisplay.animate([
                { transform: 'scale(1)', filter: 'brightness(1)', opacity: 1 },
                { transform: 'scale(1.5)', filter: 'brightness(3)', opacity: 0, offset: 0.3 },
                { transform: 'scale(0.5)', filter: 'brightness(2)', opacity: 0, offset: 0.6 },
                { transform: 'scale(1)', filter: 'brightness(1)', opacity: 1 }
            ], {
                duration: 1500,
                easing: 'cubic-bezier(.47,1.64,.41,.8)'
            });
        
            setTimeout(() => particles.forEach(p => p.remove()), 1500);
        }, 
        matrix: () => {
            const finalNumber = generateNumber();
            let iterations = 0;
            const maxIterations = 20;
            const interval = setInterval(() => {
                numberDisplay.textContent = Math.floor(Math.random() * 10);
                numberDisplay.style.color = `hsl(${Math.random() * 360}, 100%, 50%)`;
                iterations++;
                if (iterations >= maxIterations) {
                    clearInterval(interval);
                    numberDisplay.textContent = finalNumber;
                    numberDisplay.style.color = '';
                    adjustFontSize();
                }
            }, 50);
        },
        rainbow: () => {
            numberDisplay.animate([
                { color: '#ff0000', textShadow: '0 0 20px #ff0000' },
                { color: '#ff8800', textShadow: '0 0 20px #ff8800' },
                { color: '#ffff00', textShadow: '0 0 20px #ffff00' },
                { color: '#00ff00', textShadow: '0 0 20px #00ff00' },
                { color: '#0000ff', textShadow: '0 0 20px #0000ff' },
                { color: '#ff00ff', textShadow: '0 0 20px #ff00ff' },
                { color: '#ff0000', textShadow: '0 0 20px #ff0000' }
            ], {
                duration: 2000,
                iterations: Infinity
            });
        }
    };

    function generateNumber() {
        const min = parseInt(minInput.value) || 1;
        const max = parseInt(maxInput.value) || 100;
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    function playSound() {
        if (soundToggle.checked) {
            soundEffect.currentTime = 0;
            soundEffect.play().catch(() => {});
        }
    }

    themeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            document.body.setAttribute('data-theme', btn.dataset.theme);
        });
    });

    generateBtn.addEventListener('click', () => {
        const selectedAnimation = animationSelect.value;
        
        numberDisplay.getAnimations().forEach(anim => anim.cancel());
        
        if (selectedAnimation !== 'matrix') {
            numberDisplay.textContent = generateNumber();
            adjustFontSize();
        }
        
        // Add earthquake effect
        document.body.animate([
            { transform: 'translate(0px, 0px)' },
            { transform: 'translate(-5px, -5px)' },
            { transform: 'translate(5px, -5px)' },
            { transform: 'translate(-5px, 5px)' },
            { transform: 'translate(5px, 5px)' },
            { transform: 'translate(0px, 0px)' }
        ], {
            duration: 300,
            easing: 'cubic-bezier(.47,1.64,.41,.8)'
        });
    
        animations[selectedAnimation]();
        
        container.animate([
            { transform: 'scale(0.98)' },
            { transform: 'scale(1)' }
        ], {
            duration: 200,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        });

        playSound();
        generateBtn.classList.add('clicked');
        setTimeout(() => generateBtn.classList.remove('clicked'), 200);
    });

    let rafId = null;
    let targetRotateX = 0;
    let targetRotateY = 0;
    let currentRotateX = 0;
    let currentRotateY = 0;

    container.addEventListener('mousemove', (e) => {
        const { left, top, width, height } = container.getBoundingClientRect();
        const x = (e.clientX - left) / width;
        const y = (e.clientY - top) / height;
        
        targetRotateX = (y - 0.5) * 15;
        targetRotateY = (x - 0.5) * 15;
        
        if (!rafId) {
            rafId = requestAnimationFrame(updateTilt);
        }
    });

    container.addEventListener('mouseleave', () => {
        targetRotateX = 0;
        targetRotateY = 0;
        if (!rafId) {
            rafId = requestAnimationFrame(updateTilt);
        }
    });

    function updateTilt() {
        const easing = 0.1;
        
        currentRotateX += (targetRotateX - currentRotateX) * easing;
        currentRotateY += (targetRotateY - currentRotateY) * easing;
        
        container.style.transform = `perspective(1000px) rotateX(${currentRotateX}deg) rotateY(${currentRotateY}deg)`;
        
        if (Math.abs(targetRotateX - currentRotateX) > 0.01 || Math.abs(targetRotateY - currentRotateY) > 0.01) {
            rafId = requestAnimationFrame(updateTilt);
        } else {
            rafId = null;
        }
    }

    document.body.setAttribute('data-theme', 'cyber');
});
